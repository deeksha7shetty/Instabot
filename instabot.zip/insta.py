from instabot import Bot
bot = Bot()
bot.login(username = "deeksha7shetty",password = "dee@163001")
bot.follow("diljitdosanjh")

# 1.run pip install instabot
# 2.pip list
# 3.enter the code in any python file.
# 4.cd downloads(file should be present in downloads)
# 5.cd qr(this is a folder where python file i s present)
# 6.python insta.py 
# Program will be executed.